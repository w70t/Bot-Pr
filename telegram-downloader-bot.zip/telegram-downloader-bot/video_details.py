# هذا هو الكود الكامل والصحيح لملف video_details.py

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import CallbackContext

def get_detail_message(context: CallbackContext, lang: str, key: str, **kwargs):
    """Gets a message from the messages dictionary stored in context."""
    messages = context.bot_data.get('messages', {})
    lang_messages = messages.get(lang, {})
    if key not in lang_messages:
        lang = 'en'
        lang_messages = messages.get(lang, {})
    return lang_messages.get(key, f"Missing: {key}").format(**kwargs)

async def send_details_offer(update: Update, context: CallbackContext, video_info: dict):
    """Sends a message with a button offering to show video details."""
    user_languages = context.bot_data.get('user_languages', {})
    lang = user_languages.get(str(update.effective_user.id), 'en')
    
    context.user_data['last_video_info'] = video_info
    
    keyboard = [[InlineKeyboardButton(get_detail_message(context, lang, 'details_button'), callback_data='details_show')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(get_detail_message(context, lang, 'details_offer'), reply_markup=reply_markup)

async def handle_details_callback(update: Update, context: CallbackContext):
    """Handles the 'Show Details' button press."""
    query = update.callback_query
    await query.answer()
    
    user_languages = context.bot_data.get('user_languages', {})
    lang = user_languages.get(str(update.effective_user.id), 'en')
    video_info = context.user_data.get('last_video_info')

    if not video_info:
        await query.edit_message_text("Sorry, I don't have the details for that video anymore.")
        return

    title = video_info.get('title', 'N/A')
    uploader = video_info.get('uploader', 'N/A')
    view_count = video_info.get('view_count')

    details_text = f"**{get_detail_message(context, lang, 'details_title')}**\n\n"
    details_text += f"🎬 **{get_detail_message(context, lang, 'details_video_title')}:** {title}\n"
    details_text += f"👤 **{get_detail_message(context, lang, 'details_uploader')}:** {uploader}\n"
    if view_count is not None:
        details_text += f"👁️ **{get_detail_message(context, lang, 'details_views')}:** {view_count:,}"

    await query.edit_message_text(text=details_text, parse_mode='Markdown')
